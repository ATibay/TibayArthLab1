package com.car;

public class Test {

	public static void main(String[] args) {
		Car c1 = new Car ("AWD","V8","Black", "SUV", "Automatic", "Diesel", 6.5, 120, 1500000, 5.0);
		System.out.println("Car : c1");
		System.out.println("Drivetrain : " + c1.getDriveTrain());
		System.out.println("Engine : " + c1.getEngine());
		System.out.println("Color : " + c1.getColor());
		System.out.println("Body : " + c1.getBody());
		System.out.println("Transmission : " + c1.getTransmission());
		System.out.println("Fuel Type : " + c1.getFuelType());
		System.out.println("Fuel Capacity : " + c1.getFuelCapacity());
		System.out.println("Engine Output : " + c1.getEngineOutput());
		System.out.println("Price Range : " + c1.getPriceRange());
		System.out.println("Displacement : " + c1.getDisplacement());
		c1.regulateTemp("Yes.");
		c1.safetyFeature("Airbags and Seatbelts.");
		c1.shiftGears(6);
		System.out.println();
		
		Car c2 = new Car ("FWD", "Inline 4", "Grey", "Sedan", "Automatic", "Gasoline", 10, 87, 995000, 1.5);
		System.out.println("Car : c2");
		System.out.println("Drivetrain : " + c2.getDriveTrain());
		System.out.println("Engine : " + c2.getEngine());
		System.out.println("Color : " + c2.getColor());
		System.out.println("Body : " + c2.getBody());
		System.out.println("Transmission : " + c2.getTransmission());
		System.out.println("Fuel Type : " + c2.getFuelType());
		System.out.println("Fuel Capacity : " + c2.getFuelCapacity());
		System.out.println("Engine Output : " + c2.getEngineOutput());
		System.out.println("Price Range : " + c2.getPriceRange());
		System.out.println("Displacement : " + c2.getDisplacement());
		c2.regulateTemp("Yes.");
		c2.safetyFeature("Airbags, Parking Assist, and Seatbelts.");
		c2.shiftGears(6);
		System.out.println();
		
		Car c3 = new Car("AWD", "Inline 6", "Silver", "Pick up", "Manual", "Diesel", 85, 247, 2800000, 5.0);
		System.out.println("Car : c3");
		System.out.println("Drivetrain : " + c3.getDriveTrain());
		System.out.println("Engine : " + c3.getEngine());
		System.out.println("Color : " + c3.getColor());
		System.out.println("Body : " + c3.getBody());
		System.out.println("Transmission : " + c3.getTransmission());
		System.out.println("Fuel Type : " + c3.getFuelType());
		System.out.println("Fuel Capacity : " + c3.getFuelCapacity());
		System.out.println("Engine Output : " + c3.getEngineOutput());
		System.out.println("Price Range : " + c3.getPriceRange());
		System.out.println("Displacement : " + c3.getDisplacement());
		c3.regulateTemp("Yes.");
		c3.safetyFeature("Airbags, Parking Assist, and Seatbelts.");
		c3.shiftGears(6);
		System.out.println();
		
		Car c4 = new Car("AWD", "V8", "Red", "Sport Coup�", "Automatic", "Gasoline", 80, 340, 11000000, 5.0);
		System.out.println("Car : c4");
		System.out.println("Drivetrain : " + c4.getDriveTrain());
		System.out.println("Engine : " + c4.getEngine());
		System.out.println("Color : " + c4.getColor());
		System.out.println("Body : " + c4.getBody());
		System.out.println("Transmission : " + c4.getTransmission());
		System.out.println("Fuel Type : " + c4.getFuelType());
		System.out.println("Fuel Capacity : " + c4.getFuelCapacity());
		System.out.println("Engine Output : " + c4.getEngineOutput());
		System.out.println("Price Range : " + c4.getPriceRange());
		System.out.println("Displacement : " + c4.getDisplacement());
		c4.regulateTemp("Yes.");
		c4.safetyFeature("Airbags, Parking Assist, Sensors, and Seatbelts.");
		c4.shiftGears(8);
		System.out.println();
		
		Car c5 = new Car("FWD", "Inline 4", "Orange", "Hatchback", "Automatic", "Gasoline", 55, 68, 635000, 1.2);
		System.out.println("Car : c5");
		System.out.println("Drivetrain : " + c5.getDriveTrain());
		System.out.println("Engine : " + c5.getEngine());
		System.out.println("Color : " + c5.getColor());
		System.out.println("Body : " + c5.getBody());
		System.out.println("Transmission : " + c5.getTransmission());
		System.out.println("Fuel Type : " + c5.getFuelType());
		System.out.println("Fuel Capacity : " + c5.getFuelCapacity());
		System.out.println("Engine Output : " + c5.getEngineOutput());
		System.out.println("Price Range : " + c5.getPriceRange());
		System.out.println("Displacement : " + c5.getDisplacement());
		c5.regulateTemp("Yes.");
		c5.safetyFeature("Airbags, Parking Assist, and Seatbelts.");
		c5.shiftGears(6);
		System.out.println();
		
		
	}
		

}
